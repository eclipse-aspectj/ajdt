/* *******************************************************************
 * Copyright (c) 2005 Contributors.
 * All rights reserved. 
 * This program and the accompanying materials are made available 
 * under the terms of the Eclipse Public License v1.0 
 * which accompanies this distribution and is available at 
 * http://eclipse.org/legal/epl-v10.html 
 *  
 * Contributors: 
 *   Adrian Colyer			Initial implementation
 * ******************************************************************/
package org.aspectj.internal.lang.reflect;

import org.aspectj.lang.reflect.PerClause;
import org.aspectj.lang.reflect.PerClauseKind;
import org.aspectj.lang.reflect.PointcutExpression;

/**
 * @author colyer
 *
 */
public class PerClauseImpl implements PerClause {

	private final PerClauseKind kind;
	private final PointcutExpression pointcutExpression;
	
	protected PerClauseImpl(PerClauseKind kind, String pointcutExpression) {
		this.kind = kind;
		this.pointcutExpression = new PointcutExpressionImpl(pointcutExpression);
	}
	
	/* (non-Javadoc)
	 * @see org.aspectj.lang.reflect.PerClause#getKind()
	 */
	public PerClauseKind getKind() {
		return kind;
	}

	/* (non-Javadoc)
	 * @see org.aspectj.lang.reflect.PerClause#getPointcutExpression()
	 */
	public PointcutExpression getPointcutExpression() {
		return pointcutExpression;
	}

}
